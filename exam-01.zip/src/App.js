import logo from './logo.svg';
import './App.css';
import {useState} from 'react'


function HeaderComp(props) {
  console.log(props);
  return (
    <header>
        <h1>
          <a href="/">{props.title}</a>
        </h1>
    </header>
  );
}

function NavComp(props) {

  // props.changeText('바뀐다');

  // console.log('log입니다.');
  // console.error('err입니다.');
  // console.warn('warn입니다.');

  // props = {
  //   topics: [
  //     {id: 1, title: 'html2'},
  //     {id: 2, title: 'css'},
  //     {id: 3, title: 'js'},
  //   ]
  // }
  
// var list = [
//   <li><a href={"/read/" +props.topics[0].id}>{props.topics[0].title}</a></li>,
//   <li><a href={"/read/2" + props.topics[1].id}>{props.topics[1].title}</a></li>,
//   <li><a href={"/read/3" + props.topics[2].id}>{props.topics[2].title}</a></li>
// ]

var list = [];
// for(var i=0;i<props.topics.length;i++) {
//   list.push( <li><a href={"/read/" +props.topics[i].id}>{props.topics[i].title}</a></li> );
// }

// for(i=0;i<arr.length-8;i++) {
//  
//}

// for in
// for of 
// var index = 0;
// for(var item of props.topics) {
//   list.push( <li><a href={"/read/" +item.id}>{item.title}</a></li> );
//   index++;
// }

props.topics.forEach((item) => {
  list.push( <li><a href={"/read/" +item.id} onClick={function(e){
    // e.preventDefault();
    // props.changeText(item.title);
    alert('jhi')
  }}>{item.title}</a></li> );
});
// foreach , each
// map function, peek

  return (
    <nav>
      <ol>
        {list}
      </ol>
    </nav>
  );
}

function ArticleComp(props) {
  //var text = props.yours;

  // 두번째 방법 아티클 컴포넌트가 상태를 가진다.
  // const [text, setText] = useState(props.yours);
  return (
    <article>
        <h2>Welcome</h2>
        Hello, {props.yours}
    </article>
  );
}


function App() {
  var vars = {
    name: '오영재'
  };

  var topics_arr = [
    {id: 1, title: 'html'},
    {id: 2, title: 'css'},
    {id: 3, title: 'js'},
    {id: 4, title: 'react'},
    {id: 5, title: 'react2'},
  ]

  // 첫번째 방법 App 컴포넌트가 상태를 가진다.
  const [text, setText] = useState('World');


  return (
    <div>
        <HeaderComp title="안녕하세요">
          {vars}
          </HeaderComp>
        <NavComp topics={topics_arr} changeText={setText}/>
        <ArticleComp yours={text}/>
    </div>
  );
}

export default App;
